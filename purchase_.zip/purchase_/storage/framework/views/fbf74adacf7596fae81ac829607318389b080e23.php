
 
<?php $__env->startSection('title_Vendor', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title_'); ?>
<h5 id="form">Vendor</h5><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="shadow p-3 mb-5 bg-white rounded">
        <form action="<?php echo e(route('Vendor.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <a href="#" onclick="history.back()" class="btn btn-success">Back</a>
        <?php if(Auth::user()->level=='admin'): ?>
            <button type="submit" class="btn btn-success">Save</button>            
            <button type="reset" class="btn btn-success">Discard</button>
            <?php endif; ?><br><br>
            <div class="form-group container col-md-10">
                <div class="row">
                    <div class="col-md-2">
                        <label for="email">Vendor Name</label>
                    </div>
                    <div class="col-md-3">
                        <input required type="text" name="vendor_name" id="vendor_name" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <label for="phone">Phone</label>
                    </div>
                    <div class="col-md-3">
                        <input required type="text" name="phone" id="phone" class="form-control">
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-md-2">
                        <label for="address">Vendor Address</label>
                    </div>
                    <div class="col-md-3">
                        
                        <textarea required type="text" name="vendor_address" id="vendor_address" class="form-control" cols="5" rows="5"></textarea>
                    </div>
                    <div class="col-md-2">
                        <label for="email">Email</label>
                    </div>
                    <div class="col-md-3">
                        <input required type="text" name="email" id="email" class="form-control">
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-md-2">
                        <label for="type">Type</label>
                    </div>
                    <div class="col-md-3">
                        <select name="type" id="type" class="form-control" required>
                            <option value="best_partner">Best Partner</option>
                            <option value="casual">Casual</option>
                        </select>
                    </div>
                </div><br>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templateWithOutSearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\GitHub\Laravel\purchase_\resources\views/vendor_create.blade.php ENDPATH**/ ?>