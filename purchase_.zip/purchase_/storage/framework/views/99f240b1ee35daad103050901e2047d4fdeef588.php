
 
<?php $__env->startSection('title_Users', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_'); ?>
<h5 id="form">Users</h5><br>
<?php $__env->stopSection(); ?>

<?php if(Auth::user()->level == 'admin'): ?>

<?php $__env->startSection('content'); ?>
    <div class="shadow p-3 mb-5 bg-white rounded">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php elseif($message = Session::get('error')): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <a href="<?php echo e(url('Users/create')); ?>" class="btn btn-success">CREATE</a><br><br>
        <table class="table">
            <tr>
                <th>No</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Level</th>
            </tr>
            <?php $no=1 ?>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>            
            <tr>                
                <td><a href="<?php echo e(route('Users.edit', $vendors->id_user)); ?>"><?php echo e($no++); ?></a></td>
                <td><?php echo e($vendors->name); ?></td>
                <td><?php echo e($vendors->email); ?></td>
                <td><?php echo e($vendors->level); ?></td>                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    Data Purchase Request belum Tersedia.
                </div>
            <?php endif; ?> 
        </table>
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Downloads\purchase_\resources\views/user.blade.php ENDPATH**/ ?>