
 
<?php $__env->startSection('title_PO', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title_'); ?>
<h5 id="form">Purchase Order </h5><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="shadow p-3 mb-5 bg-white rounded">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <!-- <a href="<?php echo e(url('RequestQuotations')); ?>" class="btn btn-success">CREATE</a><br><br> -->
        <br>
        <table class="table table-striped table-hover">
            <tr>
                <th>No</th>
                <th>Purchase Order</th>
                <th>Vendor Name</th>
                <th>Product</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
            <?php $no=1 ?>
            <?php $__empty_1 = true; $__currentLoopData = $po; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>           
            
            <tr  class="border px-4 py-2" onclick="window.location=' <?php echo e(route('PurchaseOrder.show',$vendors->id_po)); ?>' " style="cursor: pointer;">               
       
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($vendors->id_po); ?></td>
                <td><?php echo e($vendors->vendor_name); ?></td>
                <td><?php echo e($vendors->produk); ?></td>
                <td><?php echo e($vendors->created_at); ?></td>
                <td><?php echo e($vendors->status); ?></td>                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    Data Purchase Orders belum Tersedia.
                </div>
            <?php endif; ?> 
        </table>
        <?php echo e($po->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\GitHub\Laravel\purchase_\resources\views/po.blade.php ENDPATH**/ ?>