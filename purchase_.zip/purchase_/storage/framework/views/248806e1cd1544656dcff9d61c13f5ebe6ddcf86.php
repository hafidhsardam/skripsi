
 
<?php $__env->startSection('title_PurReq', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_'); ?>
<h5 id="form">Purchase Request</h5><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="shadow p-3 mb-5 bg-white rounded">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <a href="<?php echo e(url('PurchaseRequest/create')); ?>" class="btn btn-success">CREATE</a><br><br>
        <table class="table">
            <tr>
                <th>No</th>
                <th>Purchase Request</th>
                <th>Vendor Name</th>
                <th>Product</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
            <?php $no=1 ?>
            <?php $__empty_1 = true; $__currentLoopData = $pur_req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>            
            <tr>                
                <td><a href="<?php echo e(route('PurchaseRequest.show', $vendors->id_purchase)); ?>"><?php echo e($no++); ?></a></td>
                <td><?php echo e($vendors->id_purchase); ?></td>
                <td><?php echo e($vendors->vendor_name); ?></td>
                <td><?php echo e($vendors->produk); ?></td>
                <td><?php echo e($vendors->created_at); ?></td>
                <td><?php echo e($vendors->status); ?></td>                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    Data Purchase Request belum Tersedia.
                </div>
            <?php endif; ?> 
        </table>
        <?php echo e($pur_req->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\purchase_\resources\views/pr.blade.php ENDPATH**/ ?>