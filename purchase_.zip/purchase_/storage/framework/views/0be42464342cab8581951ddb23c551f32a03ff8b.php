
 
<?php $__env->startSection('title_RFQ', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_'); ?>
<h5 id="form">Request for Quotation</h5><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
<div class="shadow p-3 mb-5 bg-white rounded">
        <form method="post" action="<?php echo e(route('PurchaseOrder.store')); ?>" id="dynamic_form">
            <input type="text" hidden name="id_purchase" id="id_purchase" value="<?php echo e($qr->id_purchase); ?>">
        <?php echo csrf_field(); ?>
        <!-- <?php echo method_field('PUT'); ?>         -->
        <a href="<?php echo e(route('PurchaseRequest.create')); ?>" class="btn btn-success">Back</a>
        <?php if($qr->status == 'Approved'): ?>
        <button type="submit" class="btn btn-success">Create PO</button><br><br>
        <?php elseif(Auth::user()->level == 'admin'&&$qr->status == 'Waiting Approval'): ?>
        <a href="<?php echo e(route('RequestQuotations.edit', $qr->id_quotation)); ?>" class="btn btn-success">Approved</a>
        <?php endif; ?>
        <div class="container col-md-9"><br>
            <div class="row">
                <div class="col-md-6">                    
                    <h2><?php echo e($qr->id_quotation); ?></h2>
                </div>         
                <div class="col-md-6">
                    <p>Status: <?php echo e($qr->status); ?></p>
                </div>
            </div><br>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                        <label for="vendor">Vendor</label>
                        <select readonly class="form-control" name="vendor_id" id="vendor">
                        <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($vendors->id_vendor); ?>"
                                <?php if($qr->id_vendor==$vendors->id_vendor): ?> selected <?php endif; ?> >
                                <?php echo e($vendors->vendor_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                    <div class="col-md-6">
                        <label for="create_date">Create Date</label>
                        <input readonly value="<?php echo e(Carbon\Carbon::parse($qr->created_at)->format('Y-m-d')); ?>" class="form-control"type="date" name="create_date" id="create_date">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                        <label for="notes">Notes</label>
                        <input readonly value="<?php echo e($qr->notes); ?>" class="form-control"type="text" name="notes" id="notes">
                    </div>
                    <div class="col-md-6">
                        <label for="order_date">Order Date</label>
                        <input readonly value="<?php echo e($qr->order_date); ?>" class="form-control"type="date" name="order_date" id="order_date">
                    </div>
                </div>
            </div>
        </div><br><br>
        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Description</th>
                    <th>Unit of Measure</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Subtotal</th>
                </tr>                    
            </thead>
            <tbody>
            <?php $total = 0; ?>
                <?php $__empty_1 = true; $__currentLoopData = $apalah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendorss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <tr>
                        <td><select readonly name="product_code" id="product_code" class="form-control">
                        
                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($produks->id_produk); ?>"
                                <?php if($vendorss->id_produk==$produks->id_produk): ?> selected <?php endif; ?> >
                                <?php echo e($produks->nama_produk); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                        </td>
                        <?php $total += $vendorss->price; ?>
                        <td><input readonly type="text" name="description" value="<?php echo e($vendorss->deskripsi); ?>" class="form-control" /></td>
                        <td><input readonly type="text" name="unit" value="<?php echo e($vendorss->unit); ?>" class="form-control" /></td>
                        <td><input readonly type="number" name="qty" value="<?php echo e($vendorss->qty); ?>" class="form-control" /></td>
                        <td><input readonly type="text" name="priceEach" value="<?php echo e($vendorss->priceEach); ?>" class="form-control" /></td>
                        <td><input readonly type="number" name="price" value="<?php echo e($vendorss->price); ?>" class="form-control" /></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-danger">
                        Data Purchase Request belum Tersedia.
                    </div>
                <?php endif; ?>
                    <tr>
                        <td>Total: <?php echo e($total); ?></td>
                    </tr>
            </tbody>
        </table>
    </form>
    <p>This data was created by <?php echo e($users->name); ?> on <?php echo e($users->created_at); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\purchase_\resources\views/qr_show.blade.php ENDPATH**/ ?>