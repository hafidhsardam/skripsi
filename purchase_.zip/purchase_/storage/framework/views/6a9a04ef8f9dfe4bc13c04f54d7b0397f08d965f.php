 
<?php $__env->startSection('title_Dashboard', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    <h5 id="form">Dashboard</h5><br>
    <!-- <div class="shadow p-3 mb-5 bg-white rounded">
        <a href="<?php echo e(URL::to('Users/create')); ?>" class="btn btn-success">CREATE</a><br><br>
        <table class="table">
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Username</th>
                <th>Level</th>
            </tr>
            <tr></tr>
        </table>
    </div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Downloads\purchase_\resources\views/home.blade.php ENDPATH**/ ?>