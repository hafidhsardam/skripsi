
 
<?php $__env->startSection('title_PurReq', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title_'); ?>
<h5 id="form">Purchase Request</h5><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="shadow p-3 mb-5 bg-white rounded">
        <form method="post" action="<?php echo e(route('PurchaseRequest.store')); ?>" id="dynamic_form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <a href="#" onclick="history.back()" class="btn btn-success">Back</a>
        <?php if($pur_req->status == "Canceled"): ?>                
        <a href="<?php echo e(route('PurchaseRequest.edit', $pur_req->id_purchase)); ?>" hidden class="btn btn-success">Edit</a>
        <?php elseif($pur_req->status == "In Process"): ?>
        <a href="<?php echo e(URL::to('StoreRFQ', $pur_req->id_purchase)); ?>" class="btn btn-success">Create RFQ</a><br><br>
        <?php else: ?>
        <a href="<?php echo e(route('PurchaseRequest.edit', $pur_req->id_purchase)); ?>" hidden class="btn btn-success">Edit</a>
        <a href="<?php echo e(URL::to('quotations', $pur_req->id_purchase)); ?>" class="btn btn-success" hidden>Create RFQ</a><br><br>
        <?php endif; ?>
        <div class="container col-md-9">
            <div class="row">
                <div class="col-md-6">                    
                    <h2><?php echo e($pur_req->id_purchase); ?></h2>
                </div>         
                <div class="col-md-4">
                    <p>Status: <?php echo e($pur_req->status); ?></p>
                </div>
                <div class="col-md-1">
                    <a href="<?php echo e(URL::to('/invoice_PRS', $pur_req->id_purchase)); ?>" class="btn btn-success">Print</a>
                </div>
            </div><br>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                        <label for="vendor">Vendor</label>
                        <select readonly class="form-control" name="vendor_id" id="vendor">
                        <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($vendors->id_vendor); ?>"><?php echo e($vendors->vendor_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                    <div class="col-md-6">
                        <label for="create_date">Create Date</label>
                        <input readonly value="<?php echo e($pur_req->created_at->format('Y-m-d')); ?>" class="form-control"type="date" name="create_date" id="create_date">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                        <label for="notes">Notes</label>
                        <textarea name="notes" class="form-control" id="notes" cols="5" rows="5" readonly><?php echo e($pur_req->notes); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label for="order_date">Order Date</label>
                        <input readonly value="<?php echo e($pur_req->order_date); ?>" class="form-control"type="date" name="order_date" id="order_date">
                    </div>
                </div>
            </div>
        </div><br><br>
        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Description</th>
                    <th>Unit of Measure</th>
                    <th>Quantity</th>
                </tr>                    
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pur_prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendorss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <tr>
                        <td><select readonly name="product_code" id="product_code" class="form-control">
                        
                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($produks->id_produk); ?>"
                                <?php if($vendorss->id_produk==$produks->id_produk): ?> selected <?php endif; ?> >
                                <?php echo e($produks->nama_produk); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                        </td>
                        <td><input readonly type="text" name="description" value="<?php echo e($vendorss->deskripsi); ?>" class="form-control" /></td>
                        <td><input readonly type="text" name="unit" value="<?php echo e($vendorss->unit); ?>" class="form-control" /></td>
                        <td><input readonly type="number" name="qty" value="<?php echo e($vendorss->qty); ?>" class="form-control" /></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-danger">
                        Data Purchase Request belum Tersedia.
                    </div>
                <?php endif; ?>
            </tbody>
        </table>
    </form>
    <p>This data was created by <?php echo e($users->name); ?> on <?php echo e($users->created_at); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templateWithOutSearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\GitHub\Laravel\purchase_\resources\views/pr_show.blade.php ENDPATH**/ ?>