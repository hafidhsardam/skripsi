
 
<?php $__env->startSection('title_Vendor', 'active'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title_'); ?>
<h5 id="form">Vendor</h5><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="shadow p-3 mb-5 bg-white rounded">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <?php if(Auth::user()->level=='admin'): ?>
        <a href="<?php echo e(url('Vendor/create')); ?>" class="btn btn-success">CREATE</a><br><br>
        <?php endif; ?>
        <table class="table">
            <tr>
                <th>No</th>
                <th>Vendor Name</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
            </tr>
            <?php $no=1 ?>
            <?php $__empty_1 = true; $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>            
            <tr>                
                <td><a href="<?php echo e(route('Vendor.edit', $vendors->id_vendor)); ?>"><?php echo e($no++); ?></a></td>
                <td><?php echo e($vendors->vendor_name); ?></td>
                <td><?php echo e($vendors->address); ?></td>
                <td><?php echo e($vendors->phone); ?></td>
                <td><?php echo e($vendors->email); ?></td>                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    Data Vendor belum Tersedia.
                </div>
            <?php endif; ?> 
        </table>
        <?php echo e($vendor->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Downloads\purchase_\resources\views/vendor.blade.php ENDPATH**/ ?>